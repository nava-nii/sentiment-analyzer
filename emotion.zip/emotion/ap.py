import streamlit as st
import pandas as pd
from textblob import TextBlob
from wordcloud import WordCloud
import matplotlib.pyplot as plt
from collections import Counter
import seaborn as sns
import nltk
from nltk.corpus import stopwords
from sklearn.feature_extraction.text import CountVectorizer

nltk.download('stopwords')
stop_words = set(stopwords.words('english'))

st.set_page_config(page_title="Sentiment Dashboard", layout="wide")

st.title("Public Consultation Sentiment Analyzer")
st.markdown("Analyze citizen feedback and discover key concerns.")

# ✅ FILE UPLOADER
uploaded_file = st.file_uploader("Upload your CSV file", type=["csv"])

if uploaded_file is not None:

    df = pd.read_csv(uploaded_file)

    # Automatically take first column if "Comment" not found
    if "Comment" in df.columns:
        comments = df["Comment"].dropna().astype(str).tolist()
    else:
        comments = df.iloc[:, 0].dropna().astype(str).tolist()

    # ---------------- VIEW ALL COMMENTS ----------------
    if st.button("View All Comments"):
        st.subheader("All Comments")
        for c in comments:
            score = TextBlob(c).sentiment.polarity
            if score > 0:
                st.markdown(f"<p style='color:green;font-weight:bold;'>• {c}</p>", unsafe_allow_html=True)
            elif score < 0:
                st.markdown(f"<p style='color:red;font-weight:bold;'>• {c}</p>", unsafe_allow_html=True)
            else:
                st.markdown(f"<p style='color:black;'>• {c}</p>", unsafe_allow_html=True)

    # ---------------- VIEW QUESTIONS ----------------
    if st.button("View Questions Asked"):
        st.subheader("Questions Asked")
        questions = [c for c in comments if "?" in c]
        if questions:
            for q in questions:
                st.write("-", q)
        else:
            st.write("No questions found in the dataset.")

    # ---------------- ANALYZE ----------------
    if st.button("Analyze"):

        pos, neg, neu = 0, 0, 0

        for c in comments:
            score = TextBlob(c).sentiment.polarity
            if score > 0:
                pos += 1
            elif score < 0:
                neg += 1
            else:
                neu += 1

        # Metrics
        colA, colB, colC = st.columns(3)
        colA.metric("Total Comments", len(comments))
        colB.metric("Positive %", round(pos/len(comments)*100,1))
        colC.metric("Negative %", round(neg/len(comments)*100,1))

        col1, col2 = st.columns(2)

        # PIE CHART
        with col1:
            fig1, ax1 = plt.subplots(figsize=(4,4))  # smaller size
            ax1.pie(
                [pos, neg, neu],
                labels=['Positive','Negative','Neutral'],
                autopct='%1.1f%%',
                colors=['green','red','yellow']
            )
            st.pyplot(fig1)

        # WORD CLOUD
        with col2:
            text = " ".join([w for c in comments for w in c.split() if w.lower() not in stop_words])
            wc = WordCloud(width=400, height=250, background_color="white").generate(text)
            fig2, ax2 = plt.subplots(figsize=(4,3))
            ax2.imshow(wc, interpolation='bilinear')
            ax2.axis("off")
            st.pyplot(fig2)

        # TOP WORDS
        words = [w.lower() for c in comments for w in c.split() if w.lower() not in stop_words]
        common = Counter(words).most_common(10)
        df_common = pd.DataFrame(common, columns=["Word","Frequency"])

        st.subheader("Top Repeated Words")
        fig3, ax3 = plt.subplots(figsize=(6,4))
        sns.barplot(x="Frequency", y="Word", data=df_common, ax=ax3, palette="viridis")
        st.pyplot(fig3)

        # TOP PHRASES
        vectorizer = CountVectorizer(ngram_range=(2,2), stop_words='english')
        X = vectorizer.fit_transform(comments)
        phrases = Counter(vectorizer.get_feature_names_out()).most_common(5)

        st.subheader("Top Phrases")
        for p,f in phrases:
            st.write(f"{p} ({f} times)")

        # SUMMARY
        st.subheader("Summary")

        if pos > neg:
            st.markdown("<h4 style='color:green;'>Majority Sentiment: Positive</h4>", unsafe_allow_html=True)
        elif neg > pos:
            st.markdown("<h4 style='color:red;'>Majority Sentiment: Negative</h4>", unsafe_allow_html=True)
        else:
            st.markdown("<h4 style='color:orange;'>Majority Sentiment: Neutral</h4>", unsafe_allow_html=True)

        st.write("Top concerns:", ", ".join([w for w,_ in common[:5]]))

else:
    st.info("Please upload a CSV file to begin analysis.")
